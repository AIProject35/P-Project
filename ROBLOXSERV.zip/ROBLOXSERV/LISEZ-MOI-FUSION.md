# Ton paquet est fusionné — ce qui a changé en arrivant

Version du place : `2026-10-17 06:30` (affichée dans la Sortie au démarrage).

## Repris tel quel

- `client/Arrivee.luau` — ta cinématique, sans retouche.
- `client/Ciel.luau` — ton ciel par monde, branché après `Arrivee.start()`
  comme tu l'avais demandé.
- `shared/Data/Worlds.luau` — tes thèmes.
- `client/Hud/WorldsPanel.luau` — ton menu et son déblocage séquentiel.
- Les plots par défaut dans `Build.part` **et** `ConstructeurMap.bloc`.

## Porté à la main, pas repris

Ta base datait d'avant plusieurs chantiers de notre côté. Ces quatre
fichiers gardent donc **notre** version, avec tes apports greffés dedans :

- **`Map/Layout.luau`** : nos coordonnées (le hub déborde maintenant sur la
  pelouse du stade), plus ton `Layout.THEME`.
- **`Map/Plaza.luau`** : notre `avance` (la pelouse de liaison des mondes
  souterrains) et nos gradins, mais tout prend les couleurs du thème.
- **`Map/AfkZone.luau`** : cinq terrains au lieu de trois, chacun habillé
  selon sa **rareté**. Les dalles gardent donc leur couleur de rareté —
  seul le socle de la zone prend la pelouse du monde, sinon le mythique et
  le commun redeviennent identiques.
- **`Map/Portal.luau`** : le portail regarde le stade, pas le spawn
  (`Layout.PORTAL_REGARD`). Il est au bord avant de la place.

**`Arcade/ConstructeurMap.luau` n'a PAS été repris** : ta version perdait
les pistes de tir, les gradins du stade et les bordures. Seul le défaut
`Plastic + Studs` du `bloc` en a été extrait. Le podium et l'arche
« STADE ARCADE », eux, sont déjà supprimés de notre côté.

## Ce qui a bougé pendant que tu travaillais

- Le hub est **réagencé** : boutique de ballons et terrains AFK montés dans
  la bande de pelouse entre la place et la zone de frappe, portail et œufs
  au bord avant de la place.
- La **boutique** est en deux rangées de cinq, un socle par ballon, les plus
  chers juchés au fond.
- **Cinq terrains AFK** : les deux derniers s'achètent en Buts (2 M et
  150 M) sur leur marquage, et restent acquis après une renaissance.
- Un **tableau des meilleurs buteurs** (OrderedDataStore) posé sur la
  pelouse, face au hub, au-delà de la barrière.
- **Trois coéquipiers pour tout le monde** : les renaissances n'ouvrent plus
  d'emplacement. Ils suivent au sol, posés par un rayon.
- Le ballon du tee prend bien l'apparence du ballon équipé, et son aura
  s'éteint avec lui.

Tout est détaillé dans `CLAUDE.md`, qui est à jour.

## Avant de travailler

```bash
rokit install
rojo serve
```

`default.project.json` a changé depuis ta dernière version (il mappe
`ReplicatedFirst`) : **relance `rojo serve`**, pas seulement le plugin.

```bash
stylua src && selene src && rojo build -o build/place.rbxl
```

Les trois passent sur ce paquet.
