# Football Hub

Jeu de foot arcade sur Roblox, géré avec **Rojo** : le code vit dans ce
dossier, Roblox Studio ne sert qu'à visualiser et tester.

Il réunit deux projets dans un seul place : un **hub** (boutique, œufs,
zone AFK, renaissances) et une **zone de tir** (*Foot Arcade*), reliés par un
porte-monnaie commun.

> Pour travailler sur le projet, lis **[CLAUDE.md](CLAUDE.md)** : il contient
> l'architecture, les décisions prises, les pièges rencontrés et ce qui reste
> à faire.

## Installation

1. **Git** et **Rokit** :

   ```bash
   winget install Git.Git
   winget install Rojo.Rokit
   ```

2. Ouvre un terminal dans ce dossier et installe la toolchain :

   ```bash
   rokit install
   ```

   Ça pose les bonnes versions de `rojo`, `wally`, `stylua`, `selene` et
   `lune` dans `~/.rokit/bin` (à ajouter au PATH).

3. Installe le plugin Rojo dans Studio :

   ```bash
   rojo plugin install
   ```

## Travailler

```bash
rojo serve
```

Puis dans Studio : **Plugins → Rojo → Connect**.

Les fichiers `.luau` partent en direct vers Studio. **Mais le hub et le stade
se construisent au démarrage du serveur** : après un changement, arrête et
relance le Play, sinon tu vois l'ancienne map.

Ouvre `build/place.rbxl`, ou mieux, fais un **Enregistrer sous** vers
`game.rbxl` à la racine — `build/` est écrasé à chaque construction.

## Vérifier avant de livrer

```bash
stylua src
selene src
rojo build -o build/place.rbxl
```

Les trois doivent passer sans erreur. Le dossier `src/*/Arcade` est exclu du
linter : c'est du code vendorisé, on garde son style.

## Tester en jeu

Dans Studio, un panneau **TEST** apparaît en haut à droite, avec aussi des
raccourcis clavier :

| Touche | Effet |
|---|---|
| `F2` | +50K Buts |
| `F3` | +5K Puissance |
| `F4` | Renaître |
| `F5` | Tout au maximum |
| `F6` | Remise à zéro |
| `F7` | Auto-clic (actif ou non) |

Il n'apparaît que dans Studio, et le serveur revalide l'autorisation de son
côté. Pour l'activer sur un jeu publié, ajoute ton UserId dans
`Config.AdminUserIds` — à ne pas laisser traîner.

## Structure

```
default.project.json   -> plan de l'arbre Roblox
src/shared/            -> ReplicatedStorage.Shared (données, config, format)
src/server/            -> ServerScriptService (économie, génération du hub)
src/client/            -> StarterPlayerScripts (HUD, effets locaux)
src/*/Arcade/          -> la zone de tir, vendorisée
outils/                -> simulations lune, hors du jeu
```
