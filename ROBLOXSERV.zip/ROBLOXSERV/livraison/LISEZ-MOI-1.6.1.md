# Football Hub 1.6.1 — trois mondes, trois altitudes

Paquet à fusionner dans la 1.6. Quatorze fichiers, tous modifiés à partir de
la version que tu as livrée (« test foot 1.5 ») — rien n'est parti d'une
base plus ancienne, donc le diff devrait être propre.

`stylua src`, `selene src` et `rojo build` passent.

---

## Ce qui change, en une phrase

Les trois mondes ne sont plus trois décors de la même couleur : ils
**montent**. Midi au ras du sol, couchant déjà haut, haute atmosphère
au-dessus des nuages — et le stade de tir suit, en couleurs comme en décor.

| | Monde 1, Quartier | Monde 2, Grand Stade | Monde 3, Arène |
|---|---|---|---|
| Ciel | midi | couchant | haute atmosphère |
| Sol | vert | terre cuite | violet |
| Décor de piste | arbres, gros nuages bas | nuages hauts, avions, dirigeables | satellites, fusées |

---

## 1. Trois bugs réels, trouvés en chemin

Ils existaient déjà et ne venaient pas de ce chantier. Ce sont les trois
morceaux qu'il faut reprendre même si tu ne gardes rien d'autre.

### Le tir ne démarrait pas, et rien ne le disait

`client/init.client.luau` appelait ses neuf `start()` à la suite, **sans
filet**, avec `Arcade.start` en dernier. N'importe lequel des huit qui le
précèdent pouvait l'empêcher de tourner en levant une erreur. Le hub
s'affichait, le HUD répondait, la pelouse et le marquage de la zone étaient
là — et maintenir le clic ne chargeait aucune jauge.

Chaque module démarre maintenant sous `pcall`, comme `etage` côté serveur,
et les échecs se nomment `Client - <module> : ECHEC`.

### La caméra de tir avait un plancher absolu

`CameraTir` gardait la caméra au-dessus de la pelouse avec
`math.max(voulue.Y, 4)` — un plancher **absolu**, qui supposait que le sol
était à zéro. Les mondes étant empilés verticalement, tirer au monde 2 la
remontait de seize mille studs au-dessus du joueur. Le tir se jouait
normalement, les Buts tombaient, et on ne voyait rien.

`solDuMonde` se déduit du ballon posé devant les pieds du joueur, qui est
déjà au bon étage : on ne demande son monde à personne.

### `swoosh.wav` ne se charge plus

Roblox refuse désormais une partie des vieux `.wav` de `rbxasset://sounds/`
(« Asset is not approved for the requester »). `Config.SONS.air` était du
nombre : **la moitié du son de la frappe était muette**, et ça ne se voyait
que dans la Sortie. Remplacé par `action_falling.mp3` ; les `action_*.mp3`
viennent du pack d'animation par défaut et se chargent toujours.

---

## 2. Le stade prend les couleurs de son monde

`ConstructeurMap.construire(hauteur, nom, habillage)` — le troisième
argument est nouveau :

```lua
export type Habillage = {
	pelouse: Color3,
	pelouseClaire: Color3,
	ligne: Color3,
	neon: Color3,
	tribunes: { Color3 },
	decor: string,  -- "quartier" | "stade" | "espace"
}
```

**La zone de tir ne connaît pas `Worlds`, et ne doit pas le connaître.**
Elle reçoit des couleurs, pas un numéro de monde ; `Map.habillageDe`
traduit. Elle reste donc utilisable en dehors du hub, comme avant.

`habillage.decor` est ce qui fait l'altitude : chaque genre pose autre
chose autour de la piste. Le vide du monde 3 se raconte par ce qu'on n'y
met pas — ni arbre ni nuage, il n'y a plus d'air.

---

## 3. Un stade par monde

Les mondes sont empilés **verticalement** (même X, même Z, seul Y change),
donc un stade se construit en décalant tout d'un seul nombre.

**C'est possible parce que `bloc` est le seul endroit où ce module crée une
`Part`.** Le décalage s'applique là, une fois ; aucune des quinze fonctions
de construction n'a changé.

**Et le tir suit tout seul** : `ZoneTir.contient` ne teste que X et Z — « la
hauteur est libre, pour que sauter n'annule pas la frappe » — et
`ZoneTir.positionBallon` déduit la hauteur du sol du personnage lui-même.
Les trois stades partagent la même zone de frappe sans une ligne de plus.

`Arcade.start` bâtit celui du monde 1, puis tend sa fonction au hub par
`Map.brancherStade` — **après `Tirs.demarrer`, et dans un étage protégé**.
Un stade de monde 2 qui manque est un désagrément ; un tir qui ne démarre
pas, c'est le jeu.

**La barrière invisible et l'avancée de 90 studs de pelouse ne servent plus
qu'aux mondes sans stade.** Avec un stade, l'avancée chevauche sa pelouse à
la même hauteur (deux sols superposés, le moteur clignote entre les deux) et
la barrière enfermerait le joueur à l'entrée de sa propre piste.

---

## 4. Le ciel

**Il est posé CHEZ LE CLIENT** (`client/Ciel.luau`), et c'est le seul choix
tenable : `Lighting` est un service unique partagé par tout le serveur,
alors que deux joueurs sont dans deux mondes différents. Réglé côté serveur,
le ciel serait celui du dernier voyageur et changerait pour tout le monde à
chaque passage de portail.

**Les étoiles et les planètes sont des PIÈCES.** `Sky.StarCount` ne montre
ses étoiles **que la nuit** : à midi on n'en voit aucune, quel que soit le
nombre. Elles sont semées sur une coupole de 4 200 studs, avec un semis
déterministe — deux joueurs du même monde voient le même ciel.

**Trois réglages qui ont demandé plusieurs essais :**

- **La densité de l'`Atmosphere` sert deux fois.** Elle donne la profondeur
  du ciel, et au-delà de 0,5 elle **noie la skybox** : les nuages peints du
  ciel Roblox par défaut disparaissent. C'est la seule façon de s'en
  débarrasser sans téléverser une skybox.
- **`Glare` était à zéro.** C'est lui qui fait le halo tout autour du ciel,
  désormais réglable par monde (`theme.ciel.lueur`).
- **Les étoiles font 42 à 96 studs.** À 4 200 studs, une sphère de 24 studs
  occupe trois pixels : on la devine, on ne la voit pas.

**L'altitude d'un monde vient de `Worlds.list[n].altitude`, et de nulle part
ailleurs.** `Map/Layout.CENTRES` la lit là, et le client aussi — il en a
besoin pour poser les astres autour du bon étage.

**Les mondes sont à 16 000 studs** les uns des autres, et non plus 4 000 :
on voyait encore celui du dessous en regardant par-dessus le bord. Le
plafond est `FallenPartsDestroyHeight`, bornée à −50 000 par le moteur et
réglée à cette valeur dans `default.project.json` — **à reprendre**, sinon
tout ce qui descend sous −10 000 est détruit, joueurs compris.

Un sol opaque allant jusqu'à l'horizon a été essayé pour masquer les autres
mondes, puis retiré : ça marchait, mais c'était une rustine qui se voyait.
Cacher n'est pas la même chose que ne pas avoir.

---

## 5. La cinématique d'arrivée

Inchangée depuis la 1.5 sauf le son d'obturateur, qui était un `.wav` du
même lot refusé que `swoosh`. C'est maintenant `action_jump_land.mp3` joué
très aigu — **ça s'entend que c'est un pis-aller**. Un vrai son téléversé se
colle dans `SON_PHOTO`, en tête de `client/Arrivee.luau`.

---

## Ordre de fusion conseillé

1. `shared/Data/Worlds.luau` — tout en dépend (altitude, thèmes, décor).
2. `shared/Config.luau`, `shared/Arcade/Config.luau` — version et sons.
3. `server/Map/Layout.luau`, `server/Map/init.luau`.
4. `server/Arcade/ConstructeurMap.luau`, `Eclairage.luau`, `Tirs.luau`,
   `init.luau`.
5. `client/Ciel.luau`, `client/Arcade/CameraTir.luau`, `Frappe.luau`,
   `client/Arrivee.luau`.
6. `client/init.client.luau` en dernier.
7. `default.project.json` : `FallenPartsDestroyHeight` à −50 000.

---

## Vérifier

```bash
stylua src && selene src && rojo build -o build/place.rbxl
```

**Et le piège qui coûte un après-midi** : Studio ne recharge pas un place
déjà ouvert quand le fichier change sur le disque, et la synchro Rojo seule
ne reconstruit pas la map — le hub et les trois stades se bâtissent au
**démarrage du serveur**. Après un changement de code, il faut **arrêter et
relancer le Play**. La Sortie doit afficher la version `1.6.1`.

---

## Ce qui n'a pas été vu tourner

- Le décor du monde 3 (satellites, fusées) et celui du monde 2 (avions,
  dirigeables) n'ont jamais été vus en jeu. Ce sont des pièces simples, mais
  leurs tailles et leurs altitudes se règlent à l'œil.
- Le nombre d'étoiles du monde 3 (300) peut être chargé, et sa géante
  violette fait 2 200 studs à 2 400 de distance : elle va occuper une bonne
  part du ciel.
- Les couleurs de pelouse du monde 2 (terre cuite) sous un ciel de couchant
  n'ont pas été jugées ensemble.
