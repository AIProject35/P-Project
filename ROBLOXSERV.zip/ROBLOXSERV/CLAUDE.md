# Football Hub — contexte du projet

Jeu de foot arcade sur Roblox, né de la fusion de deux projets :

- un **hub** (boutique de ballons, œufs à coéquipiers, zone AFK, portail de
  mondes, HUD, économie, renaissances) ;
- une **zone de tir** (le projet *Foot Arcade* : jauge de puissance, frappe,
  vol du ballon, caméra cinématique, stade de 8200 studs).

Les deux tournent dans le même place et partagent un seul porte-monnaie.

## Règles de travail

**Tout en français** : code, commentaires, noms de variables, textes affichés.
Sans accents dans les fichiers `.luau` (on écrit « ameliorations »), pour
éviter les soucis d'encodage côté Studio.

**Performance** : aucune boucle serveur qui réplique à chaque image ; les
effets purement visuels vont côté client (voir `src/client/Spin.luau`, qui
fait tourner les ballons et les œufs sans aucun trafic réseau).

## Mise en route

Les outils sont gérés par **Rokit** (`rokit.toml`), dans `~/.rokit/bin` :
`rojo`, `wally`, `stylua`, `selene`, `lune`.

```bash
rokit install          # installe la toolchain
rojo serve             # synchronise src/ vers Studio
```

Dans Studio : onglet **Plugins → Rojo → Connect**.

Avant d'annoncer que c'est prêt :

```bash
stylua src && selene src && rojo build -o build/place.rbxl
```

### Deux pièges déjà rencontrés

1. **Studio ne recharge pas un place déjà ouvert** quand le fichier change sur
   le disque. On a cherché un bug inexistant pendant un tour entier à cause de
   ça. `Config.Version` est affichée au démarrage dans la Sortie : si elle ne
   correspond pas à la dernière construction, le place est périmé.
2. **Le hub et le stade se construisent au démarrage du serveur.** Après un
   changement de code, il faut **arrêter et relancer le Play** — la synchro
   Rojo seule ne reconstruit pas la map.

## Architecture

`default.project.json` fait la correspondance :

| Dossier | Destination |
|---|---|
| `src/shared` | `ReplicatedStorage.Shared` |
| `src/server` | `ServerScriptService.Server` (un `Script`) |
| `src/client` | `StarterPlayerScripts.Client` (un `LocalScript`) |
| `src/replicatedfirst` | `ReplicatedFirst.Chargement` (un `LocalScript`) |

Le code du projet *Foot Arcade* vit sous un espace de noms `Arcade` dans
chacun des trois (`src/shared/Arcade`, `src/server/Arcade`,
`src/client/Arcade`) : sans ça, son `Config`, son `Theme` et son `Reseau`
entraient en collision avec ceux du hub.

### Partagé (`src/shared`)

| Fichier | Rôle |
|---|---|
| `Config.luau` | Tous les réglages du hub et les interrupteurs du stade |
| `Progression.luau` | Les renaissances : seuil, coût, bonus |
| `Format.luau` | Affichage et lecture des grands nombres (`1.25K`, `3.2B`) |
| `Remotes.luau` | Création et accès des RemoteEvents du hub |
| `Data/Balls.luau` | Les 10 ballons : prix et multiplicateur |
| `Data/Eggs.luau` | Les 9 œufs, 3 par monde |
| `Data/Footballers.luau` | Les 27 coéquipiers, 3 par œuf, tirage pondéré |
| `Data/Fusion.luau` | Les paliers de fusion : coût, boost, identifiants |
| `Data/Gifts.luau` | Les 12 paliers de temps de jeu et leurs récompenses |
| `Data/Cleats.luau` | Les 8 crampons : prix et multiplicateur de Buts |
| `Data/Worlds.luau` | Les 3 mondes et leur seuil en renaissances |

### Serveur (`src/server`)

| Fichier | Rôle |
|---|---|
| `Economy.luau` | Le profil : porte-monnaie, ballons, équipe, renaissances |
| `Admin.luau` | Commandes de test, réservées à Studio |
| `AutoClic.luau` | Le GamePass d'auto-clic : possession, achat, test |
| `Pets.luau` | Pose les coéquipiers alignés derrière le joueur |
| `Map/` | Génération du hub : place, boutique, œufs, zone AFK, portail |
| `Map/Classement.luau` | Le tableau des meilleurs buteurs, et son OrderedDataStore |
| `Arcade/` | La zone de tir, démarrée par `Arcade.start(Economy)` |

### Client (`src/client`)

| Fichier | Rôle |
|---|---|
| `Hud/` | Menu latéral, statistiques, boutique, équipe, renaissance |
| `Hud/Theme.luau` | **Le thème : palette, polices, tailles, animations, studs** |
| `Hud/RebirthButton.luau` | Bouton de renaissance contextuel et sa confirmation |
| `Hud/FusionPanel.luau` | Le panneau de la machine à fusion |
| `Hud/GiftsPanel.luau` | Les récompenses de temps de jeu |
| `Hud/WorldsPanel.luau` | Le menu des mondes, ouvert par le portail |
| `Hud/DevPanel.luau` | Panneau de test, Studio uniquement, touches F2 à F6 |
| `AfkClic.luau` | Le bouton de clic des terrains AFK |
| `Arrivee.luau` | La caméra de la sortie des vestiaires |
| `FusionCompteur.luau` | Le compte à rebours au-dessus de la machine, local |
| `Pets.luau` | Fait suivre les coéquipiers, en local |
| `Ciel.luau` | Le ciel et l'ambiance du monde où l'on est, en local |
| `Spin.luau` | Rotation des objets en vitrine, purement local |
| `EggInfo.luau` | Panneau des coéquipiers à l'approche d'un œuf, local |
| `Signs.luau` | Dessine les étiquettes de la map en 2D, à taille constante |
| `Arcade/GesteFrappe.luau` | Le coup de pied, animé sur les articulations |
| `Arcade/FrappeParfaite.luau` | Les effets de la frappe parfaite |
| `Arcade/` | Jauge, caméra, festival de buts |

## L'écran de chargement

Il vit dans **`ReplicatedFirst`, et nulle part ailleurs** : c'est le seul
endroit dont le contenu arrive au client **avant** le reste du jeu. Posé
dans `StarterGui` ou dans `client/`, il démarrerait une fois le décor déjà à
l'écran — et Rojo efface de toute façon ce qu'on ajoute à la main sous
`Client` ou `Shared`, dont il réconcilie le contenu.

**Il ne dépend de rien.** Aucun `require` vers `Shared` ni vers le thème du
HUD : quand il démarre, `ReplicatedStorage` peut encore être vide, et
l'attendre reviendrait à se cacher derrière l'écran qu'on est en train de
construire. Ses couleurs sont donc recopiées chez lui — **c'est la seule
duplication voulue du projet**.

**Ce qu'il attend** : `ReplicatedStorage.Shared`, puis `Workspace.HubGenere`
— donc le hub réellement construit. Il ne ment pas sur l'avancement : la
jauge est le minimum entre les étapes faites et le temps écoulé, donc elle
ne promet jamais plus que ce qui est prêt et ne reste pas bloquée pleine.

**Un filet de sécurité le retire de force** au bout de 27 secondes. Un
joueur coincé derrière un écran de chargement quitte le jeu et ne revient
pas.

## L'économie

**Une seule ressource : les Buts.** Ils achètent les ballons et les œufs.
Ils vivent dans le profil du stade (`Arcade/Donnees.luau`), donc ils sont
sauvegardés en DataStore.

**Une seule statistique : la Puissance.** Elle s'accumule tir après tir et
détermine la force de frappe :

```
frappe = 1 + FrappeAmortissement x ln(1 + Puissance / PuissanceParPalier)
```

Elle n'a **pas de plafond** : la courbe est logarithmique, donc elle monte
toujours et ralentit toute seule.

Elle est branchée sur la vitesse du tir par `Tirs.brancherPuissance` : un
joueur plus puissant envoie le ballon plus loin, donc gagne plus.

**La formule** :

```
gain par lancer = PuissanceParLancer x coef des ballons x coequipiers
Puissance      += gain                      (elle s'accumule)
frappe          = 1 + 1.4427 x ln(1 + Puissance / 600)
v theorique     = 25 + 85 x jauge x frappe
Buts           += (v theorique² x 0.0018307 + 15) x renaissances x crampons
```

**Le ballon ne donne pas de Puissance** : il donne un COEFFICIENT qui
multiplie ce que chaque lancer rapporte. Un ballon s'achète **une seule
fois** et seul le meilleur possédé compte : les coefficients **ne se
cumulent pas**, un ballon remplace le précédent. C'est aussi lui qu'on voit
partir.

**Les coéquipiers** multiplient eux aussi le gain par lancer ; leurs
valeurs s'additionnent entre elles. Le multiplicateur vaut **1 + la somme**
de leurs `power`, et non `max(1, la somme)` : avec un maximum, trois
coéquipiers communs ne dépassaient pas 1 et ne servaient donc à rien. Le
fichier documentait déjà `1 + somme`, c'est le code qui avait tort.

**L'équipe s'aligne toute seule** sur les meilleurs coéquipiers possédés : à
l'éclosion, au chargement du profil et quand une renaissance ouvre un
emplacement. Chaque exemplaire compte pour lui-même, donc trois fois le même
coéquipier est une équipe valable si on en possède trois.

Le premier geste manuel dans le panneau Équipe éteint l'automatique
(`profile.autoLineup`) : on ne défait pas le choix d'un joueur qui vient de
le faire. Le bouton **ALIGNER LES MEILLEURS** le rallume — sans lui, un seul
basculement par curiosité l'aurait éteint pour de bon.

**La fusion.** Trois coéquipiers identiques en donnent **un du palier
suivant**, 2,5 fois plus fort (`Fusion.BOOST`), jusqu'au palier 4. On perd
donc un peu de puissance brute au passage — trois exemplaires pour 2,5 — et
on gagne deux emplacements : c'est tout l'intérêt, une équipe ne compte que
3 à 6 places. Fusionner n'est jamais obligatoire, c'est un choix entre la
quantité et la place.

L'identité d'un coéquipier fusionné est son identifiant **suffixé** :
`numero_dix#3`. Un identifiant sans suffixe vaut palier 1, donc tous les
enregistrements écrits avant la fusion se relisent sans rien changer.

**Tout ce qui lit une équipe passe par `Fusion.get`**, jamais par
`Footballers.get` : lui seul sait ce que vaut un palier, et c'est là que les
mutations viendront se greffer, sur le même principe — un suffixe de plus et
une seule fonction à enrichir. Pour la même raison, la relecture du profil et
le panneau Équipe parcourent l'**inventaire** et non le catalogue : un
identifiant suffixé ne figure dans aucune liste.

La machine est posée en retrait du triangle d'œufs
(`Layout.FUSION_POSITION`) : c'est aux œufs qu'on récupère les coéquipiers,
donc c'est là qu'on se rend compte qu'on a trois fois le même. L'actionner
**ouvre son panneau**, où l'on choisit quoi fabriquer.

**Une fabrication à la fois, et elle prend du temps** : 30 s pour un commun
ou un peu commun, 45 s pour un rare ou un épique, 60 s au-delà
(`Fusion.ATTENTE`). Une machine qui rendrait tout d'un coup ferait de la
fusion une formalité ; en l'attendant, on a le temps de retourner tirer.

Les trois exemplaires sont pris **au départ**, pas à l'arrivée : sinon ils
resteraient alignés pendant toute la fabrication, et on lancerait trois
fabrications avec les trois mêmes coéquipiers.

La fin est un **horodatage**, pas un compte à rebours : le temps passé hors
ligne compte, donc un joueur qui se déconnecte retrouve sa pièce faite. Une
boucle serveur d'une seconde les termine, là où un `task.delay` par
fabrication ne survivrait pas à la déconnexion. Le compte à rebours affiché,
lui, tourne chez le client — un message par seconde et par joueur pour
afficher un chiffre serait du gaspillage pur.

Il s'affiche aussi **au-dessus de la machine**, et là encore c'est le client
qui le construit : le panneau n'existe donc que chez le joueur concerné. Une
fabrication est personnelle, et trois comptes à rebours superposés au-dessus
de la même machine ne voudraient rien dire.

**Les récompenses de temps de jeu** (le bouton Cadeaux) : douze paliers, de
2 minutes à 2 heures, en Buts, en Puissance ou en œuf offert — et l'œuf passe
par le vrai tirage pondéré, donc le cadeau donne un œuf, pas un coéquipier
choisi d'avance.

**Le temps compte depuis toujours**, pas depuis le début de la session : il
est sauvegardé avec le profil (`profile.temps`), et les paliers pris le sont
aussi. Un joueur qui revient le lendemain reprend où il en était au lieu de
devoir refaire deux heures d'affilée.

**L'horloge du compte à rebours tourne chez le client.** Le serveur envoie le
temps cumulé une fois, à l'arrivée et après chaque réclamation ; le panneau
avance tout seul à partir de là. Un message par seconde et par joueur pour
afficher un chiffre qui descend serait du gaspillage, et la seule chose qui
compte — le droit de réclamer — est revérifiée côté serveur.

**Les paliers pris voyagent en LISTE** dans le DataStore, comme les mondes :
le JSON transforme les clés numériques en chaînes, et on relisait des paliers
qu'on ne reconnaissait plus.

**Les crampons** sont la seule chose qui multiplie directement les Buts.
On les garde tous et on choisit lesquels porter, un seul à la fois ; ils
survivent à la renaissance. Ils n'ont **aucun effet sur la Puissance**.

### Deux pistes qui ne se croisent jamais

C'est la règle à ne pas casser :

- la **Puissance**, en amont : ballon × coéquipiers × renaissances. Elle
  fait la force de frappe, donc la distance.
- les **Buts**, en aval : une seule fonction, `Economy.butsMultiplier`,
  vaut `débordement × renaissances × crampons`. La zone de tir la lit dans
  `ballModel().bonusButs` ; c'est le seul endroit du jeu où un
  multiplicateur de Buts a le droit d'exister.

Les renaissances sont le seul élément présent des deux côtés, et c'est
voulu : renaître tire plus loin **et** paie plus. Mettre le ballon ou les
coéquipiers dans la seconde piste les compterait deux fois.

**C'est la Puissance accumulée, et elle seule, qui fait la force du
tir**, donc la distance et la hauteur.

**Les terrains AFK** ne donnent que de la Puissance, avec un rendement de
1,5 / 3 / 5 / 8 / 12 fois la zone de tir (cadences comprises : un lancer AFK
dure 1,6 s contre 6 a 10 s pour un tir).

**Ils sont cinq, et ils s'ouvrent de DEUX façons.** Les trois premiers
s'ouvrent aux renaissances (0, 10, 25) : ils donnent un cap aux renaissances
successives. Les deux derniers **s'achètent en Buts** (2 M et 150 M) à une
borne posée devant eux — à ce stade un joueur a bien plus de Buts que
d'idées pour les dépenser, et un terrain qui tourne tout seul est exactement
ce qu'il veut acheter. **Un terrain a un prix OU un palier, jamais les
deux** : deux conditions sur la même porte, et on ne sait plus laquelle
bloque. Les terrains achetés voyagent en LISTE dans le DataStore, comme les
mondes et les cadeaux, et pour la même raison.

**Ils ont maigri pour être cinq** : leur emplacement fait 15 studs de
profond sur 30 de long, au lieu de 22 sur 40, et la plateforme est plus
étroite que son emplacement (`ECART_TERRAINS` = 4) — bord à bord, les cinq
terrains ne formaient plus qu'un grand damier. Les enseignes montent d'un
cran un terrain sur deux, sans quoi cinq étiquettes se recouvrent en
enfilade.

**Chaque terrain a sa rareté** (`AfkZone.STYLES`) : commun, rare, épique,
légendaire, mythique. Elle donne la couleur des dalles, du liseré et du
filet, et les deux terrains payants — et eux seuls — scintillent. Celui qui
coûte 150 M ressemblait sinon au premier venu.

**On achète un terrain SUR SON MARQUAGE**, pas à une borne : un bloc doré
planté devant chaque terrain payant cassait la rangée et ne servait qu'à
porter un prompt. Le prompt tient sur le rond où l'on se pose, et s'affiche
au moment où l'on vient justement s'y poser.

**Le ballon AFK meurt DANS LA TOILE.** Il s'arrêtait au milieu de la cage et
s'évanouissait en plein vol, sans qu'on sache s'il était entré. Il va
maintenant jusqu'au filet, qui recule d'un demi-stud et revient par un
rebond élastique : c'est ce petit coup qui raconte le but. Le filet est le
seul morceau de la cage que le reste du code connaît (`Lane.filet`).

**Le clic.** Sur un terrain, cliquer rapporte de la Puissance en plus du
rendement automatique : `AfkPuissanceParClic` = 0,20, **neuf clics par
seconde** au maximum, soit 1,8 par seconde — le double du rendement
automatique, donc **×3 au total** quand on clique à fond. Le rendement du
terrain multiplie les deux de la même façon, donc ce rapport tient sur les
trois terrains.

C'est la **valeur du clic** qui tient l'équilibrage, pas la cadence : monter
la cadence sans la baisser revient à offrir le plafond à l'auto-clic, qui
l'atteint, lui, sans jamais fatiguer. Les neuf par seconde sont un plafond,
pas un objectif — personne ne le tient longtemps à la main, et c'est ce qui
laisse sa place au pass.

**Les clics partent par paquets de 150 ms**, et pas un par message : à neuf
par seconde, un message par clic ferait onze messages par seconde et par
joueur pour un compteur qui ne se lit pas plus vite. Le nombre annoncé dans
le paquet n'engage personne, c'est le seau de jetons qui tranche.

**La cadence est comptée côté serveur**, et nulle part ailleurs : un seau de
jetons par joueur, qui ne garde jamais plus d'une seconde de réserve. Le
bouton du client envoie un peu plus vite que le quota pour que le seau reste
plein, et le surplus est refusé. Plafonner côté client seulement n'aurait
protégé de rien : un client modifié envoie mille clics par seconde.

**L'auto-clic** fait ces neuf clics par seconde à la place du joueur, tant
qu'il est posé sur un terrain. Il se vend en **GamePass**, donc en Robux :
un service qui tourne pendant l'absence du joueur ne peut pas se payer en
Buts, sinon il s'auto-finance en quelques minutes. `Config.AutoClicGamePassId`
vaut 0 tant que le pass n'est pas créé sur le site Roblox — rien n'est alors
en vente, et seule la touche F7 l'active. Il s'achète au kiosque posé à
l'entrée de la zone AFK, et une petite offre s'affiche en haut à gauche en
arrivant sur un terrain :
au plus une fois toutes les cinq minutes, jamais si le joueur l'a déjà, et
pas du tout tant que le pass n'existe pas — sauf en Studio, pour pouvoir la
régler. Une offre qui se rouvre à chaque aller-retour devient une publicité,
et se ferme sans se lire.

**Les Buts** ne dépendent que de la distance atteinte et du débordement
de puissance au-delà du plafond de force.

**L'accès aux mondes s'achète en Buts** (`Worlds.price`), et reste acquis
après une renaissance.

**La renaissance** ne consomme QUE la Puissance accumulée à l'entraînement.
Les Buts, les ballons et les coéquipiers restent acquis : on ne rachète
jamais ce qu'on a déjà payé. Elle a **deux effets** : +15 % de Puissance
permanents (`REBIRTH_BONUS_GROWTH`, multiplicatif, qui porte aussi le rythme
des renaissances suivantes) et **+0,25 au multiplicateur de Buts par tir**
(`Config.RenaissanceBoostParPalier`, additif). Le second est celui qui
s'affiche à l'écran de renaissance : le premier passe par la distance, donc
par un chiffre que personne ne compare de tête.
Les paliers ronds débloquent : terrain AFK 2 (renaissance 10) et terrain 3
(25) ; les terrains 4 et 5 s'achètent en Buts. **Pas d'emplacement
d'équipe** : ils s'ouvraient jusqu'à six, et une
file de six coéquipiers barrait l'écran du joueur. L'équipe compte **trois
places pour tout le monde**, et c'est la fusion qui la fait monter.

### Pourquoi le tir est comprimé, et pas plafonné

Le terrain fait 8200 studs. À la renaissance 50, la portée théorique est de
43 km : le ballon partait dans le décor. Plafonner la force aurait réglé ça,
mais au prix d'un mur — c'est ce qu'on faisait avec `ForceMax = 9`, et tout
ce qui dépassait devait être récupéré par un multiplicateur séparé.

À la place, on sépare **deux vitesses** (`Config.lancer`) :

- la **théorique**, sans plafond, qui compte les Buts ;
- la **rendue**, comprimée par une tangente hyperbolique, qui lance le
  ballon. Elle tend vers `VITESSE_RENDUE_MAX`, donc la portée tend vers
  ~7 400 studs sans jamais y buter.

Une grosse frappe ne se voit donc plus à la distance mais à la trajectoire :
plus la compression mord, plus l'angle s'abaisse vers `ANGLE_TIR_MIN` et
plus le ballon part vite et tendu, pour une portée au sol identique.

Le terrain est gradué par paliers (`Config.GRADUATIONS`) : des traits tous
les 10 studs près du tee, tous les 250 au loin. Graduer 8000 studs au pas
de 10 ferait 800 marqueurs illisibles.

## Les mondes

**Chaque monde est un hub complet**, posé à son propre centre
(`Layout.CENTRES`). Les suivants sont **SOUS TERRE**, à 4 000 studs
d'intervalle : pendant un tir la caméra monte à plus de 400 studs et voit à
des milliers de studs à la ronde, donc aucune distance horizontale ne les
aurait cachés.

**Quatre mille studs, et pas deux mille** : les bornes de distance du stade
sont des BillboardGui dimensionnés en studs, avec une portée qui va jusqu'à
3 000. À 2 000, on lisait encore leurs chiffres dans le ciel du monde 2.

**Ils se construisent à la demande**, au premier joueur qui y entre. Un
serveur où personne n'a débloqué le monde 2 ne paie donc rien : ni les
pièces, ni leur réplication à chaque arrivée.

**`Layout.viser(monde)` repose le centre du hub ailleurs** et recalcule
toutes les coordonnées dérivées. Les constructeurs lisent `Layout` au moment
où ils bâtissent, donc ils n'ont rien eu à changer. **Le piège qui va
avec** : hors construction, ces champs valent ceux du dernier monde visé.
Personne ne doit les lire à l'exécution — les boucles des terrains AFK
gardent les positions qu'elles ont résolues à la construction, et c'est ce
qui rend ce raccourci sans danger.

**UN SEUL PORTAIL PAR MONDE**, et il ne vise rien en particulier : il ouvre
un menu où l'on choisit sa destination (`Hud/WorldsPanel`). Deux portails
côte à côte — un pour aller, un pour revenir — obligeaient à en construire
un de plus par monde ajouté, et aucun des deux ne disait où l'on pouvait
aller.

**Le menu ne décide de rien** : il envoie un numéro de monde, et le serveur
vérifie l'accès, débite s'il le faut, et emmène. Il vend **puis emmène** :
personne n'achète un monde pour rester à la porte.

**On revient au monde 1 en mourant**, puisque c'est lui qui porte le
`SpawnLocation` — d'où le `mondeDe[player]` remis à 1 à chaque apparition.

**Les mondes souterrains reçoivent un socle** de 360 studs, n'ayant pas la
pelouse du stade pour les porter, et **pas de point d'apparition** : avec
deux `SpawnLocation`, on réapparaîtrait au hasard de l'un ou l'autre. Pas de
boutique de ballons non plus — les dix ballons sont les mêmes partout.

**`FallenPartsDestroyHeight` NE SE REGLE PAS DEPUIS UN SCRIPT.** La
documentation est formelle : « can only be set by plugins, the command bar,
or the properties window in Studio ». Une assignation depuis un script
serveur **lève une erreur**, et comme elle était dans `Map.build`, elle a
emporté tout le démarrage : ni hub, ni stade, ni tirs, juste le ciel. Elle
est donc posée dans `default.project.json`, que Rojo applique avec les
droits d'un plugin. Elle est bornée entre −50 000 et 50 000.

**Et il faut qu'elle descende avec les mondes.** Elle vaut **−500** par
défaut : tout ce qui passe en dessous est **détruit**, parenté à `nil`. Un
joueur téléporté au monde 2, à −2 000, était donc supprimé à l'arrivée — on
croyait à une chute, c'était le moteur qui faisait le ménage.

**Chaque étage du démarrage est protégé** (`init.server.luau`, fonction
`etage`) : une erreur dans l'un ne peut plus emporter les suivants. On l'a
appris en perdant tout pour une seule ligne fautive, et un écran vide ne dit
pas où chercher.

**L'arrivée dans un monde est une CINÉMATIQUE, pas un décor.** Le tunnel des
vestiaires n'existe nulle part dans la map : il est bâti **par le client du
joueur qui voyage**, autour de son point d'arrivée, et détruit à la fin de
la scène. Personne d'autre ne le voit, et le hub n'en garde aucune trace —
une première version le posait en dur dans le monde, et il traînait là,
vide, le reste de la partie.

Le serveur ne fait que deux choses : déposer le joueur **quarante studs en
arrière du centre**, face à lui, et lui dire où courir. Il finit donc au
milieu du monde, comme au monde 1, et c'est la course qui fait la scène
(`Humanoid:MoveTo`, qui joue l'animation sans rien animer).

**Ce que les autres joueurs voient** : le personnage traverser la pelouse,
et rien d'autre. Ni tunnel, ni bandes noires, ni caméra — tout ça n'existe
que chez le voyageur. La scène porte aussi un bouton **Passer**, qui dépose
tout de suite au centre : on ne force pas quelqu'un à regarder dix fois la
même arrivée.

## Un stade de tir par monde

**Chaque monde a sa propre piste**, et elle ne coûte presque rien. Les
mondes sont empilés **verticalement** — même X, même Z, seul Y change
(`Layout.CENTRES`) — donc un stade se construit en décalant tout d'un seul
nombre.

**C'est possible parce que `ConstructeurMap.bloc` est le seul endroit où ce
module crée une `Part`.** Le décalage s'applique là, une fois, et aucune des
quinze fonctions de construction n'a eu à changer d'une ligne.

**Et le tir suit tout seul, pour une raison qui n'a rien d'un hasard** :
`ZoneTir.contient` ne teste que X et Z — « la hauteur est libre, pour que
sauter n'annule pas la frappe » — et `ZoneTir.positionBallon` déduit la
hauteur du sol **du personnage lui-même**. Les trois stades partagent donc
la même zone de frappe sans une ligne de plus.

**Deux hauteurs étaient écrites en dur, et elles seules :**

- `Tirs` comparait `ballon.Position.Y` à un seuil fixe pour compter les
  rebonds. Un ballon tiré à −4 000 n'atteignait donc **jamais** l'altitude
  qui le compte comme « en l'air » : aucun rebond, et le tir ne se terminait
  que par la sécurité de durée. La hauteur se compte maintenant depuis
  `depart.Y - RAYON_BALLON` — le ballon posé devant les pieds du joueur est
  déjà au bon étage, donc **son point de départ porte la réponse**, sans
  qu'on ait à demander son monde à personne.
- L'onde de choc de `Frappe` s'étalait à `y = 0,3`, donc au niveau du
  monde 1 pendant qu'on tirait quatre mille studs plus bas.

**Qui construit quoi** : `Arcade.start` bâtit le stade du monde 1, puis
tend sa fonction au hub par `Map.brancherStade` — **après `Tirs.demarrer`,
et dans un étage protégé**. Posé avant et sans `pcall`, il tenait tout le
reste en otage : une erreur là interrompait `Arcade.start` avant le système
de tir, et plus personne ne pouvait tirer nulle part. Un stade de monde 2
qui manque est un désagrément ; un tir qui ne démarre pas, c'est le jeu. Les suivants se
construisent avec leur monde, au premier joueur qui y entre. C'est le hub
qui appelle, et pas l'inverse : lui seul sait quand un monde s'ouvre et à
quelle altitude il est posé, et le hub n'a donc pas à connaître
`ConstructeurMap`. Si la zone de tir échoue à démarrer, les mondes se
construisent quand même — sans piste, mais entiers.

**Chaque stade a son propre dossier** (`Stade`, `Stade2`, `Stade3`) : trois
dossiers nommés « Stade » et le premier trouvé ferait foi pour tout le
monde. Et **un seul porte un `SpawnLocation`**, pour la même raison qu'un
seul monde en porte un.

## Ne pas voir les autres mondes

**Les mondes sont à 16 000 studs les uns des autres**, et c'est la seule
chose qui règle le problème. À 4 000 on voyait encore celui du dessous en
regardant par-dessus le bord : un monde fait 150 studs de large, et Roblox
rend très bien une pelouse de cette taille à quatre mille studs. À 16 000,
ils ne sont tout simplement plus rendus.

**On a essayé de les masquer avec un sol opaque** qui allait jusqu'à
l'horizon. Ça marchait, et c'était une rustine : elle se voyait, elle
apparaissait sous les pieds quand on tombait, et elle ajoutait un décor que
personne n'avait demandé. Cacher n'est pas la même chose que ne pas avoir.
Retiré.

**Le plafond est `FallenPartsDestroyHeight`**, bornée à −50 000 par le
moteur et réglée à cette valeur dans `default.project.json`. Tout ce qui
passe dessous est détruit, joueurs compris. Avec trois mondes, 16 000 studs
d'écart posent le dernier à −32 000 et laissent 18 000 studs de marge sous
ses pieds. Un quatrième monde tiendrait ; un cinquième non, et il faudrait
alors resserrer l'écart ou passer à des places séparées.

Au-delà, la précision des nombres flottants se dégrade : Roblox conseille de
rester sous 100 000 studs de l'origine, et le ballon part déjà à 7 000 studs
depuis le monde où il est tiré.

## Un ciel par monde

Il vit dans `Worlds.list[n].theme.ciel` et il est posé **chez le client**
(voir plus haut, `client/Ciel.luau`) : `Lighting` est unique pour tout le
serveur, alors que deux joueurs peuvent être dans deux mondes différents.

## Trois mondes, trois altitudes

**C'est la règle qui tient tout le reste** : on ne change pas seulement de
couleur en changeant de monde, on monte.

| | Monde 1, Quartier | Monde 2, Grand Stade | Monde 3, Arène |
|---|---|---|---|
| Ciel | midi | couchant | haute atmosphère |
| Sol | vert | terre cuite | violet |
| Décor | arbres, gros nuages bas | nuages hauts, avions, dirigeables | satellites, fusées |
| Air | dense | dense, doré | dense, lueur forte |

**LE STADE DE TIR PREND LES COULEURS DE SON MONDE.** Il était vert pour les
trois : on changeait de monde, le hub changeait de palette, et la piste —
la moitié du jeu où l'on passe le plus de temps — restait la même pelouse.
`ConstructeurMap.construire` prend un `Habillage` (pelouse, lignes, néons,
tribunes, genre de décor).

**La zone de tir ne connaît pas `Worlds`, et ne doit pas le connaître.**
Elle reçoit des couleurs, pas un numéro de monde ; c'est `Map.habillageDe`
qui traduit. Elle reste ainsi utilisable en dehors du hub.

**Le décor de la piste est ce qui fait l'altitude.** `habillage.decor` vaut
`"quartier"`, `"stade"` ou `"espace"`, et chaque genre pose autre chose :
des arbres et des nuages bas qu'on traverse du regard, puis des nuages
passés au-dessus de la tête avec des avions dedans, puis plus d'air du tout
— seulement des satellites et des fusées. Le vide se raconte par ce qu'on
n'y met pas.

**L'HEURE DÉCIDE DE LA HAUTEUR DE LA BANDE LUMINEUSE, PAS LE `Glare`.**
C'est le réglage le plus mal compris des trois ciels, et il a coûté deux
passes. Le `Glare` ne fait qu'intensifier le halo **là où le soleil se
trouve** : soleil bas, on obtient une bande nette au ras de l'horizon et le
ciel reste propre au-dessus ; soleil haut, le même réglage répand la lueur
sur tout le ciel et lave le décor. Le monde 2 en a fait les frais — à
17 h 24 le soleil était encore haut, et un `Glare` de 0,55 noyait la piste
dans un orange uniforme où plus rien ne se lisait.

Les trois mondes ont donc le **soleil bas**, et leur progression est aussi
une progression d'heure : **16 h, 18 h, 20 h 24**. Le monde 3 est le ciel de
référence, celui dont la bande basse a donné le ton — ne pas y toucher sans
regarder les trois.

**La bande se dessine par l'ÉCART entre `air` et `horizon`**, pas par leur
valeur absolue. Un horizon franchement plus saturé que l'air donne une
bande nette ; deux couleurs proches donnent un aplat.

**LES NUAGES SONT DES PIÈCES, jamais une texture de ciel.** Et c'est la
**L'ATMOSPHÈRE NE PEUT PAS EFFACER LES NUAGES PEINTS**, et on a perdu deux
passes à essayer. Elle est la plus **mince au zénith** — exactement là où
on les regarde en levant les yeux — et n'épaissit que vers l'horizon, où il
n'y a déjà plus rien à masquer. Monter la densité jusqu'à 0,64 n'y a rien
changé. La seule façon de s'en défaire est de **remplacer la skybox**
(`theme.ciel.skybox`, six faces) ; la densité est revenue à ce pour quoi
elle est bonne, la profondeur du ciel, donc les nuages du ciel Roblox par défaut
disparaissent dans l'aplat. C'est la seule façon de s'en défaire sans
téléverser une skybox, et c'est pour ça que les trois mondes sont montés
au-dessus de ce seuil. La même densité donne la profondeur du ciel, et
`lueur` (`Atmosphere.Glare`) le halo tout autour.

**LES TROIS CIELS MONTENT :** midi au Terrain du Quartier, couchant au
Grand Stade, haute atmosphère à l'Arène Galactique. Chacun garde son moment,
et c'est ce qui donne l'impression de progresser. Deux essais ont été
écartés : une nuit bleue au monde 2, qui volait au monde 3 son entrée dans
l'espace ; et un minuit noir au monde 3 (clarté 1,3), où l'on ne distinguait
plus les œufs de la pelouse.

**Le monde 1 a le même traitement que les autres.** Il n'avait longtemps ni
Atmosphere ni teinte, pour « garder son apparence d'origine » : à côté des
deux autres, il ressortait comme le ciel Roblox brut, plat et sans
profondeur.

**Les étoiles et les planètes sont des PIÈCES**, pas des réglages.
`Sky.StarCount` ne montre ses étoiles **que la nuit** : à midi on n'en voit
aucune, quel que soit le nombre. Un monde qui veut des étoiles en plein jour
doit donc les porter lui-même. `Ciel.poserAstres` les sème sur une coupole
et pose les planètes déclarées dans `theme.ciel.planetes` — côté client, donc
chaque joueur n'a dans son ciel que les astres de son monde.

**Le semis est déterministe** (`Random.new` sur le numéro du monde) : deux
joueurs du même monde voient le même ciel, et revenir dans un monde le
retrouve tel qu'on l'avait laissé. Au hasard, les constellations se
redessinaient à chaque passage de portail.

**La coupole s'est rapprochée (5 500 → 4 200 studs) et les planètes avec
elle.** Sous une atmosphère dense, tout ce qui est loin se noie dans la
brume : les planètes étaient à peine visibles et les étoiles pas du tout.
Une planète sombre à cinq mille studs n'est pas une planète, c'est une
tache.

**Elles sont grosses — 42 à 96 studs.** À 5 500 studs, une sphère de 24
studs occupe trois pixels : on la devine, on ne la voit pas. Une étoile de
ciel doit faire une dizaine de pixels pour se lire comme un point lumineux
et non comme un défaut d'image.

**Le rayon de la coupole est borné par l'écart entre les mondes** : ils sont
à 16 000 studs, donc une coupole de 9 000 planterait les étoiles du monde 2
au ras du sol du monde 1. Elle est à 5 500.

**L'altitude d'un monde vient de `Worlds.list[n].altitude`, et de nulle part
ailleurs.** `Map/Layout.CENTRES` la lit là, et le client aussi — il en a
besoin pour poser les astres autour du bon étage. Écrite des deux côtés,
elle finissait par ne plus correspondre.

**UN SKYBOX DE LA BIBLIOTHÈQUE N'EST PAS UN IDENTIFIANT, C'EN EST SIX.** Ce
qu'on y trouve est un objet `Sky` complet ; son numéro de modèle ne se colle
pas dans une face. Deux façons de s'en servir :

- `theme.ciel.skybox` — les six chaînes écrites à la main. Elles **gagnent
  toujours**, ne coûtent rien au démarrage et ne peuvent pas échouer.
- `theme.ciel.skyboxModele` — le numéro du modèle. `server/Skybox.luau`
  l'insère au démarrage (`InsertService:LoadAsset`, refusé au client), lit
  ses six faces et les pose en attribut sur `ReplicatedStorage`, d'où elles
  partent seules vers chaque client. Un seul nombre à coller.

**Le client peut être prêt avant le serveur**, le chargement partant sur le
réseau : `Ciel` écoute l'attribut et repose le ciel quand les faces
tombent — sans ça le joueur gardait le ciel par défaut jusqu'à son prochain
voyage. C'est à ça que sert le paramètre `force` de `Ciel.appliquer`, qui
contourne le garde « c'est déjà ce monde ».

**Rien n'en dépend** : si le chargement échoue — asset privé, retiré,
modéré — le monde garde le ciel Roblox par défaut et la Sortie le dit.

**C'est la SKYBOX qui fait qu'un monde a un autre ciel**, pas l'Atmosphere.
Sans elle, les trois mondes partagent le ciel bleu par défaut de Roblox,
seulement teinté différemment — on peut beaucoup pousser la teinte, on ne
change pas les nuages. Le champ `skybox` prend les six faces du cube de ciel
(`rbxassetid://…`) ; laissé à `nil`, le monde garde le ciel par défaut.

**Les six faces sont reposées à chaque changement de monde**, y compris en
chaînes vides pour un monde qui n'en déclare pas : sans ça, on gardait le
ciel du monde précédent en revenant à un monde qui n'a pas de skybox.

**LA BARRIÈRE ET L'AVANCÉE DE PELOUSE NE SERVENT QU'AUX MONDES SANS
STADE.** Elles datent de l'époque où les mondes souterrains étaient des
îlots. Avec un stade, les deux deviennent nuisibles : l'avancée va jusqu'à
z = +10 et chevauche la pelouse du stade, qui commence à z = −80 et se
trouve à la **même hauteur** — deux sols superposés, et le moteur clignote
entre les deux. Quant à la barrière, elle s'arrête à z = +21 : elle
enfermerait le joueur à l'entrée de sa propre piste.

**Les mondes souterrains sont entourés d'une barrière invisible**, pas posés
sur un socle. Un socle plein faisait l'affaire mais se voyait de partout —
une grande dalle noire sous tout le monde — alors qu'on ne lui demandait que
d'empêcher une chute.

**L'arrivée est une CINÉMATIQUE SUR SON PROPRE PLATEAU**, et surtout pas le
hub filmé. Le serveur dépose le joueur au centre du monde et donne le
départ ; tout le reste est construit par son client à **douze mille studs
de tout** : un couloir de vestiaires, une pelouse, des gradins, trois
figurants et un ballon.

Quatre plans : gros plan dans le couloir, sortie en courant sous les flashes
des photographes, plan large sur les coéquipiers, panoramique sur les
gradins. Les durées sont quatre constantes en haut du module.

**C'est un DOUBLE du joueur qui est filmé**, pas son personnage. Le vrai
appartient au serveur : le déplacer sur un plateau que le serveur ne voit
pas le ferait tomber dans le vide, et les autres joueurs le verraient
disparaître. On clone, on filme le clone, et le vrai attend au centre. Un
clone ne fait plus tourner son script `Animate`, donc on charge la course
en reprenant **ses** identifiants d'animation, lus dans le `Animate` du
clone — ce sont ceux de son avatar, pas ceux d'un autre.

## Les thèmes de monde et le ciel

**Chaque monde porte son thème** (`Data/Worlds.theme`) : deux tons de
pelouse, la couleur des lignes peintes, celle des néons, les trois rangs de
tribunes, et un bloc `ciel`. Les trois mondes étaient des copies visuelles
exactes — payer 400 000 Buts pour le monde 2 donnait le même décor que le
monde 1.

`Layout.viser(monde)` repose `Layout.THEME` en même temps que les
coordonnées, et il porte **exactement le même piège** : hors construction, il
vaut celui du dernier monde visé. Les constructeurs le lisent pendant qu'ils
bâtissent, personne ne le relit en cours de partie.

**Les dalles des terrains AFK gardent la couleur de leur RARETÉ**, pas celle
du monde : c'est ce qui distingue les cinq terrains les uns des autres, et ça
ne doit pas changer d'un monde à l'autre. Seul leur socle prend la pelouse du
monde.

**LE CIEL EST POSÉ CHEZ LE CLIENT** (`client/Ciel.luau`), et c'est le seul
choix tenable : `Lighting` est un service unique, partagé par tout le
serveur, alors que deux joueurs peuvent être dans deux mondes différents.
Réglé depuis le serveur, le ciel serait celui du **dernier voyageur**, et il
changerait sous les yeux de tous les autres à chaque passage de portail. Le
module écrit donc dans son propre `Lighting` ; son `Sky`, son `Atmosphere` et
son `ColorCorrectionEffect` n'existent que chez lui. Il revient au monde 1
sur `CharacterAdded`, comme le serveur remet `mondeDe` à 1 : sans ça, un
joueur mort dans l'arène réapparaissait au Terrain du Quartier sous un ciel
étoilé.

**`Ciel.start()` se branche APRÈS `Arrivee.start()`**, et l'ordre compte :
les deux écoutent le même remote `Arrivee`, les abonnés sont appelés dans
leur ordre de branchement, et la cinématique couvre l'écran de noir dès sa
première ligne. Branché avant, on voit le ciel sauter pendant une image.
`Config.ArcadeEclairage` doit rester à `false`, sinon le stade poserait un
`Sky` répliqué qui se battrait avec celui du client.

**Le remote `Arrivee` porte le NUMÉRO DU MONDE.** Sans lui, ni la scène ni le
ciel ne savent où l'on vient d'arriver.

**Les mondes s'ouvrent DANS L'ORDRE, et c'est vérifié côté serveur.** Le menu
grise déjà la rangée, mais rien n'empêche un client modifié d'envoyer le
dernier numéro et de sauter toute la progression en payant une seule fois.

**Les plots sont le DÉFAUT des deux fabriques de pièces** (`Build.part` et
`ConstructeurMap.bloc`) : `Plastic` + `TopSurface = Studs`. Comme le moteur
ne les dessine que sur `Plastic`, une pièce qui demande du Neon, du Metal ou
du SmoothPlastic n'en montre aucun sans qu'on ait à le dire — c'est ce qui
permet de plotter tout le jeu d'une ligne par module.

## Décisions à connaître

- **Le hub possède le `SpawnLocation`.** `Config.CREER_APPARITION = false`
  empêche `Arcade/ConstructeurMap` de détruire celui du hub et de créer le
  sien. Repasse-le à `true` pour retrouver son podium d'origine.
- **Le `leaderstats` est partagé** : le stade y met « Buts » et « Record »,
  le hub « Puissance ». `Synchro.creerClassement` complète le dossier
  existant au lieu de le remplacer.
- **Le hub se génère dans `Workspace.HubGenere`, pas dans `Workspace.Map`.**
  Rojo réconcilie le contenu de `Map` et effacerait ce qu'on y crée à
  l'exécution.
- **Le hub est posé en `Layout.CENTER` = (0, 0, -139)**, bord à bord avec
  l'arrière de la pelouse du stade qui commence à z = -80. Déplacer ce seul
  vecteur déplace tout le hub.
- **LE HUB DÉBORDE SUR LA PELOUSE DU STADE.** La place ne fait que 118 studs
  de profond et tout y tenait ; la grande bande de pelouse entre elle et la
  zone de frappe, elle, ne servait à rien. Les deux zones où l'on passe du
  temps sont donc montées de part et d'autre de cette bande — **la boutique
  à gauche (-X), les terrains AFK à droite (+X)**, entre z = -78 et z = -13.
  La place ne garde que ce qu'on fait en passant : apparaître, ouvrir un
  œuf, fusionner, voyager. Son bord avant porte le **portail à gauche** et le
  **triangle d'œufs à droite**, la machine à fusion juste derrière eux.
  Ce qui porte ces zones au monde 1, c'est la pelouse du stade ; dans les
  mondes souterrains, c'est la **place qui s'avance de 90 studs** vers le
  stade (`Plaza.build`, option `avance`) : sans cette pelouse de liaison, on
  arrivait au bord de la place et il n'y avait plus rien jusqu'aux zones,
  posées cent studs plus loin. La barrière invisible est à 160 studs du
  centre, donc tout reste dedans.
- **Le portail regarde le STADE, pas le spawn** (`Layout.PORTAL_REGARD`) :
  posé au bord avant de la place, on l'a de face en revenant du terrain — le
  moment où l'on pense à changer de monde.
- **Le tableau des meilleurs est sur la pelouse, à z = +60**, donc
  **au-delà de la barrière** (z = +10) : on ne peut pas l'atteindre, et c'est
  voulu — il se lit depuis la zone de frappe, en regardant le terrain. Il ne
  **retient pas le ballon** (`CanCollide = false`), sans quoi un tir rasant
  rebondirait dessus. Il n'existe qu'au **monde 1** : les mondes souterrains
  n'ont que leur place, il y flotterait dans le vide.
- **L'ambiance lumineuse du stade est coupée** (`ArcadeEclairage = false`) :
  elle lavait toute la scène. Ses mâts de projecteurs restent posés, c'est du
  décor.
- **Les commandes de chat ne fonctionnent pas** : TextChatService traite tout
  message commençant par `/` comme une commande et ne le transmet jamais à
  `Player.Chatted`. D'où le panneau de test et les touches F2 à F6.
- **Chaque bloc du HUD est construit à part** (`Hud/init.luau`, fonction
  `bloc`) : si l'un échoue, les autres vivent et la Sortie nomme le coupable.
- **CHAQUE MODULE CLIENT DÉMARRE À PART** (`client/init.client.luau`,
  fonction `demarrer`), pour la même raison, et ça a coûté une session. Les
  neuf `start()` étaient appelés à la suite sans filet, `Arcade.start` en
  dernier : n'importe lequel des huit qui le précèdent pouvait l'empêcher de
  tourner en levant une erreur. Le hub s'affichait, le HUD répondait, la
  pelouse et le marquage de la zone étaient là — et maintenir le clic ne
  chargeait aucune jauge. **Rien à l'écran ne disait que le tir n'avait
  jamais été branché.** Les échecs se nomment désormais `Client - <module> :
  ECHEC`.
- Pour un **Cylinder**, Roblox prend `size.X` comme hauteur et `size.Y`/`size.Z`
  comme diamètre.
- **Les panneaux 3D sont dimensionnés EN PIXELS** (`Build.sign`), pas en studs.
  En studs, le texte rétrécit avec la distance et devient illisible dès
  qu'on recule ; en pixels, il garde la même taille à l'écran. Le texte est
  détaché par un `UIStroke` épais sur chaque lettre, pas par un fond :
  un fond posait de grosses bulles noires devant le décor. `Build.banner`
  n'est plus qu'une ancre invisible.
- **Chaque zone du hub est construite a part** (`Map/init.luau`, fonction
  `zone`), comme les blocs du HUD. Une reference cassee dans la boutique
  a deja laisse le hub reduit a sa pelouse, sans aucun message dans la
  Sortie : les zones suivantes n'etaient jamais construites.
- **LES AVATARS N'ONT PLUS DE `Motor6D`.** Depuis l'*Avatar Joint Upgrade*,
  actif par défaut, un personnage R15 est articulé par des
  `AnimationConstraint`. Chercher un `Motor6D` ne trouve donc **rien**, et
  une boucle sur zéro articulation ne se plaint pas : le code tourne, ne
  lève aucune erreur, et il ne se passe simplement rien à l'écran. Trois
  essais ont été perdus là-dessus. `GesteFrappe` accepte les deux familles
  et **prévient dans la Sortie** quand il ne trouve aucune articulation.
- **On ne pose pas un geste avec `C0`.** La documentation est explicite :
  pour animer, c'est `Transform` qu'on écrit. Et comme l'`Animator` réécrit
  `Transform` à chaque image, il faut écrire APRÈS lui — sur
  `RunService.PreSimulation` — et **multiplier** par ce qu'il vient de poser
  au lieu de l'écraser : `joint.Transform = CFrame.Angles(a, 0, 0) *
  joint.Transform`. C'est ce qui superpose le coup de pied à l'animation
  d'attente au lieu de se battre avec elle. On saute l'image quand
  `Animator.EvaluationThrottled` est vrai, sinon le décalage s'ajoute à une
  pose périmée et le personnage tremble.
- **Le geste est joué CHEZ LE CLIENT** (`Arcade/GesteFrappe`), et surtout
  pas sur le serveur : un `Transform` écrit côté serveur ne part pas image
  par image, la réplication de propriétés étant groupée et espacée. Le
  tireur joue le sien au relâchement de la jauge, sans attendre le serveur ;
  les autres le rejouent sur l'événement `Geste` — un message par tir au
  lieu d'une centaine de valeurs d'articulation.
- **LE PLANCHER DE LA CAMÉRA EST RELATIF AU SOL DU MONDE.** Il était écrit
  `math.max(voulue.Y, 4)` : un plancher absolu, qui supposait que la pelouse
  était à zéro. Les mondes étant empilés verticalement, tirer au monde 2 —
  à −16 000 — remontait la caméra de force seize mille studs au-dessus du
  joueur. Le tir se jouait normalement, les Buts tombaient, et on ne voyait
  rien. `CameraTir.solDuMonde` se déduit du ballon posé devant les pieds du
  joueur, qui est déjà au bon étage : on ne demande son monde à personne.
- **La caméra se règle en STUDS DE RETARD, pas en souplesse.** Un lissage
  exponentiel laisse la caméra en retard de `vitesse / souplesse` studs : à
  770 studs/s et une souplesse de 4,5, cela faisait **171 studs** de retard,
  et le ballon devenait un point — d'autant plus que la frappe était grosse.
  `Config.CAMERA.retardDepart` / `retardVol` disent le retard qu'on veut
  voir, et la souplesse en est déduite à chaque image. La hauteur
  supplémentaire quand le ballon monte est bornée par `hauteurSupMax`, sinon
  un tir qui culmine à 420 studs repoussait la caméra de 146 studs de plus.
  Résultat : le ballon occupe **4,3 % de la largeur de l'écran à toutes les
  puissances**, contre 44 à 243 studs de distance avant. Les chiffres se
  revérifient avec `lune run outils/camera.luau`.
- **Le contact est un INSTANT À PART, pas une image.** Le serveur annonce
  `Contact` au client, attend `Config.HITSTOP` (70 ms), puis seulement lance
  le ballon. Pendant cet arrêt sur image le pied reste collé au ballon, la
  jambe s'arrête en pleine course (même `task.wait` dans `AnimationFrappe`),
  et c'est là que tombent le son, l'onde de choc, la gerbe d'herbe et la
  secousse. Sans lui, le ballon passait d'immobile à 800 studs/s sur la même
  image : il n'y avait pas d'instant de contact, juste un avant et un après.
- **La secousse est violente et courte** (3,2 sur 0,14 s). À 1,4 sur 0,35 s
  elle se lisait comme un flottement de caméra : une secousse ne se sent que
  si elle est finie avant qu'on ait le temps de la regarder.
- **La caméra passe de PROFIL pendant l'armement** (`CameraTir.armer`). Vu de
  dos — la caméra normale du jeu — un coup de pied se devine à peine, la
  jambe partant derrière le corps qui la cache. Elle se cale sur
  `Config.DIRECTION_TIR` et non sur l'orientation du joueur, que le serveur
  fait pivoter au même instant. Un filet de sécurité la rend au joueur si le
  ballon ne part jamais (mort, tir refusé).
- **Le client ne devine plus le moment du contact** avec son propre minuteur :
  il attend l'événement du serveur, donc les deux côtés ne peuvent plus se
  désynchroniser.
- **Les vieux `.wav` de `rbxasset://sounds/` ne se chargent plus tous.**
  Roblox en refuse une partie (« Asset is not approved for the requester »),
  et `swoosh.wav` est tombé comme ça : la moitié du son de la frappe était
  muette sans que rien ne le signale ailleurs que dans la Sortie. Les
  `action_*.mp3` viennent du pack d'animation par défaut et se chargent
  toujours — c'est la famille à préférer.
- **`CelestialBodiesShown` est au PLURIEL.** Écrit `CelestialBodyShown`,
  Roblox lève une erreur à l'affectation. Cette seule lettre a empêché tout
  le jeu de tirer, parce que `Ciel.start` démarrait sans filet avant
  `Arcade.start` : voir la règle sur le démarrage des modules client.
- **Les sons sont regroupés dans `Config.SONS`** : deux lignes à changer pour
  passer d'un emprunt à la bibliothèque Roblox à des sons choisis. Celui de
  la frappe est joué plus grave que l'original, et sa hauteur suit la
  puissance — une frappe à 30 % claque moins fort qu'une à 95 %.
- **Le geste de frappe n'est visible que pendant `DELAI_CONTACT`.** Passe
  ce delai le ballon part. **`DELAI_CONTACT` doit toujours valoir
  `ARMEMENT` + `DETENTE`** (0,55 + 0,12 = 0,67), sinon le ballon part avant
  ou apres le pied : c'est la seule contrainte a respecter en touchant aux
  durees du geste. Il est passe de 0,45 a 0,67 parce qu'a 0,38 s d'armement,
  le geste passait trop vite pour qu'on comprenne ce qu'on regardait.
- **Le ballon a une portance de base** (`Config.PORTANCE`, 35 %) : une
  VectorForce annule une partie du poids pendant le vol (50 %). Sans elle il
  suivait une parabole sèche de balle de golf. Elle existait déjà mais
  était pilotée par l'amélioration « Portance », qu'on a supprimée :
  elle valait donc toujours zéro. Elle change la portée, donc
  `Config.VITESSE_RENDUE_MAX` doit être recalculé si on y touche.
- **Une pièce Roblox ne peut pas dépasser 2048 studs sur un axe.** Au-delà,
  le moteur rabote la taille sans prévenir : la pelouse s'est retrouvée
  trop courte et décalée, avec un trou dans lequel le joueur tombait. Le
  sol est donc posé en dalles de 2000 studs (`construireSol`).
- **Ne jamais détruire `workspace.Terrain`**.
- **Les plots du sol sont du rendu de surface, pas des pièces.**
  `TopSurface = Studs` (soit `Build.DESSUS_PLOTS`) les fait dessiner par le
  moteur, comme sur les briques Roblox d'origine. Une version précédente les
  posait en vrais cylindres, un par plot : la pelouse du hub en demandait des
  centaines à elle seule, pour un résultat moins net et une grille qui
  s'arrêtait avant les bords. Les deux moitiés du jeu en portent — le hub et
  la pelouse du stade — pour être faites de la même matière.
- **Les plots ne se dessinent que sur le matériau `Plastic`.** `Grass`,
  `Concrete` et même `SmoothPlastic` les masquent complètement : on a posé
  les surfaces une première fois en gardant l'herbe, et il ne s'est
  strictement rien passé. `Build.DESSUS_PLOTS` et `Build.MATIERE_PLOTS` vont
  donc toujours ensemble — un sol à plots est en Plastic, et c'est aussi ce
  qui lui donne son aplat de couleur franche.
- **Les chiffres du tableau viennent d'un OrderedDataStore**, pas de la liste des
  joueurs présents : un classement du seul serveur n'aurait eu qu'une ligne
  la moitié du temps. Il classe les **Buts gagnés depuis toujours**
  (`Economy.totalEarned`) et non le porte-monnaie, qui recule à chaque achat.
  Les noms voyagent dans un **second magasin**, une clé d'OrderedDataStore ne
  portant qu'un nombre. Une écriture par joueur toutes les deux minutes, une
  lecture par serveur toutes les soixante secondes ; sans accès DataStore —
  en Studio, typiquement — il retombe sur les joueurs présents plutôt que de
  rester vide. Un tableau par monde, tous remplis par la même lecture
  (tag `TableauClassement`).
- **Les coéquipiers suivent AU SOL, et c'est un RAYON qui trouve ce sol**,
  pas la hauteur du joueur : celle-ci ne vaut que sur un terrain plat, et dès
  que le joueur montait une marche, un présentoir ou l'estrade de la
  boutique, ils flottaient ou s'enfonçaient. Un rayon par coéquipier et par
  image, soit trois pour le joueur local, et il ignore les coéquipiers et
  tous les personnages — sinon ils se posent les uns sur les autres. La
  hauteur du joueur (`HAUTEUR = -1,9`) ne sert plus que de repli quand le
  rayon ne touche rien. Leur rebond part de zéro et monte, au lieu d'osciller
  autour de leur hauteur de repos : centré, il les enfonçait dans le sol une
  fois sur deux.
- **Le ballon posé sur le tee s'éteint avec `BallFx.montrer`.** Le rendre
  transparent ne suffit pas : son émetteur continue de cracher des particules
  et sa lumière d'éclairer, et c'est ce qui laissait l'aura du ballon allumée
  sur le point de tir pendant tout le vol.
- **Le ballon équipé se pousse au client par `Economy.brancherBallonEquipe`**,
  branché sur `Synchro.envoyer`. Le client ne connaît l'apparence du ballon
  que par ce paquet, qui ne partait qu'à l'arrivée : on achetait le Ballon de
  Feu et on en posait encore un autre devant ses pieds. Ce rappel est réservé
  à ce qui change le ballon — le mettre dans `refresh`, appelé plusieurs fois
  par seconde par les terrains AFK, renverrait tout le profil à chaque gain.
- **Le ballon s'arrête avec le compteur.** Le compteur de Buts du vol se
  remplit sur la portée attendue : une fois plein, il n'a plus rien à
  raconter, alors que le ballon roulait encore une seconde et demie. Dès
  qu'il retouche le sol au-delà de cette portée, la fin est programmée
  (`Config.DELAI_APRES_COMPTEUR`).
- **La boutique de ballons est en DEUX RANGÉES DE CINQ**, les cinq plus chers
  au fond, juchés 6 studs plus haut. Une file de dix stands s'étirait sur
  cent studs : il fallait la longer pour voir le dernier ballon. Cette
  différence de hauteur n'est pas décorative — sans elle, la rangée de devant
  cache celle du fond et les étiquettes se superposent. Les dix étiquettes
  sont donc à la même hauteur au-dessus de leur ballon.
- **Chaque ballon porte SON socle, et rien n'est mutualisé** : ni dalle sous
  la boutique, ni estrade derrière. Les deux grandes plaques — une sombre au
  sol, une blanche brillante au fond — se voyaient de tout le hub et
  écrasaient le reste du décor. Dix petits socles se lisent comme dix
  présentoirs, et l'herbe passe entre eux.
- **Il n'y a plus ni podium ni arche « STADE ARCADE »** au milieu du terrain :
  un disque de 68 studs et quarante studs de portique coupaient la vue, on les
  montait et descendait à chaque aller-retour, et ils nommaient un endroit où
  l'on se tient déjà. `Config.RAYON_PODIUM` survit, mais ce n'est plus une
  taille de podium : c'est l'écart entre le point d'apparition et le début de
  la zone de tir.
- **Les coéquipiers visibles sont posés par le serveur et déplacés par le
  client.** Les pièces sont **ancrées** : ce qu'un client leur fait ne repart
  vers personne, donc chacun anime sa propre copie et tout le monde les voit
  au bon endroit. Une boucle serveur qui repositionnerait trois pièces par
  joueur à chaque image, c'est précisément le trafic que ce projet s'interdit.
  Le client lit tout sur les attributs de la pièce (`Proprietaire`, `Place`,
  `Total`), qui sont répliqués d'office.
- **`Economy.brancherEquipe` est le seul branchement pour l'équipe.**
  `pushTeam` est le passage obligé de tout ce qui touche à l'alignement —
  éclosion, achat, rechargement du profil — donc un rappel posé là voit tous
  les changements, et l'économie n'a pas à connaître le module qui pose les
  pièces.
- **La file des coéquipiers part de la direction du joueur APLATIE.** Avec
  son `CFrame` tel quel, ils basculent avec lui dès qu'il saute ou qu'il
  tombe, et la file part de travers.
- **Un BillboardGui ne sait pas garder un texte à taille constante.** Sa
  taille rétrécit avec la distance, `Offset` compris, et agrandir la boîte
  pour compenser ne grossit pas le texte : `TextScaled` est plafonné. On
  obtenait une boîte énorme avec un texte minuscule, dont les lignes
  s'écartaient les unes des autres — le nom du ballon partait dans le ciel
  pendant que son prix restait sur le présentoir. Trois essais pour en
  arriver là ; aucun réglage ne rattrape ça.
- **Les étiquettes du hub sont donc de l'interface 2D.** Le serveur construit
  toujours un BillboardGui, mais il ne sert qu'à PORTER les données ;
  `client/Signs.luau` l'éteint en l'adoptant, en refait de vrais labels dans
  un `ScreenGui`, et les place à chaque image là où l'objet tombe à l'écran
  (`WorldToViewportPoint`). La taille du texte est alors une taille d'écran,
  en pixels, et rien ne la change jamais.
- **Deux conséquences à ne pas oublier** : une étiquette qui s'allume et
  s'éteint le dit par l'attribut `Actif` (son `Enabled` est éteint pour de
  bon), et le `ScreenGui` ignore le `GuiInset`, parce que
  `WorldToViewportPoint` compte en pixels de la fenêtre entière, barre Roblox
  comprise.
- **Il y a DEUX systèmes d'étiquettes.** `Map/Build.sign` pour le hub (rendu
  en 2D par `Signs`, donc à taille d'écran constante) et
  `Arcade/ConstructeurMap.panneau` pour le stade (de vrais BillboardGui en
  studs, ancrés dans le monde, qui rétrécissent avec la distance). C'est
  voulu : les bornes du stade doivent se lire à 2 000 studs. Corriger l'un ne
  corrige pas l'autre : ça a déjà coûté un tour.
- **La frappe n'a plus de plafond** : `1 + 1.4427 × ln(1 + P / 600)`. Elle
  monte toujours et ralentit seule. C'est aussi ce qui empêche l'économie
  d'exploser : une équipe qui multiplie la Puissance par 13 ne multiplie la
  frappe que par 1,4.
- **Les Buts viennent de la FRAPPE, plus de la distance parcourue.** Le
  ballon est freiné pour rester sur la piste (`Config.lancer`), donc le
  compter à l'endroit où il s'arrête aurait plafonné les gains en même temps
  que la portée. Deux vitesses, donc : la théorique compte, la rendue lance.
- **Ne jamais laisser l'angle s'aplatir pendant que la vitesse est
  plafonnée** : la portée se mettait à RE-DIMINUER quand la frappe montait.
  `Config.lancer` calcule un angle plancher depuis la marge de vitesse.
- **Ne jamais animer `Size` sur un objet qui porte une `UISizeConstraint`** :
  la contrainte rogne l'animation. Le bouton de renaissance anime un
  `UIScale`, et multiplie apparition et pulsation dans le même facteur.
- **Ne jamais mettre `TextScaled` et `AutomaticSize` sur le même label** :
  la largeur dépend du texte et la taille du texte dépend de la largeur.
- **`Theme.button` et `Theme.brique` coupent ce qui dépasse** (les plots le
  demandent). Tout ce qui doit mordre sur un bord — la pastille de
  notification, par exemple — se pose sur le cadre parent, pas dedans.
- **`StudsOffset` suit la caméra, `StudsOffsetWorldSpace` suit le monde.**
  Pour décaler un panneau « vers la droite de l'écran », c'est le premier ;
  avec le second il passait à gauche ou derrière selon l'angle de vue.
- **Le catalogue de ballons du stade (`Arcade/Boutique.BALLONS`) ne sert
  plus à rien côté hub.** Il a déjà fait afficher un ballon blanc sur le tee
  et un compteur de buts faux : tout ce qui concerne le ballon équipé passe
  par `Economy.ballAppearance` et le paquet `Synchro`.
- **Tout le style du HUD vient de `Hud/Theme.luau`.** Aucune couleur, police,
  taille de texte ni durée d'animation ne se pose ailleurs. Les polices :
  `LuckiestGuy` pour les gros chiffres et les titres, `FredokaOne` pour le
  texte courant, `GothamBold` sous 14 px.
- **Le HUD est en Scale, pas en pixels.** Les boutons sont carrés par
  `UIAspectRatioConstraint`, bornés entre `Theme.BUTTON_MIN` et
  `Theme.BUTTON_MAX`, et leur taille est recalculée depuis la hauteur
  d'écran dans `Hud/init.luau`. Les textes sont `TextScaled` bornés par un
  `UITextSizeConstraint` (`Theme.TEXT_RANGE`).
- **Ne jamais animer à la fois `Size` et une `UISizeConstraint`.** La
  contrainte rogne l'animation. Le bouton de renaissance anime donc un
  `UIScale`, et multiplie son apparition par sa pulsation dans le même
  facteur : deux tweens sur la même propriété se volent la main.
- **Ne jamais mettre `TextScaled` et `AutomaticSize` sur le même label** :
  la largeur dépend du texte et la taille du texte dépend de la largeur.
- **Les étiquettes flottantes ont deux portées** (`Build.PORTEE_ETIQUETTE`
  et `Build.PORTEE_ENSEIGNE`) : une étiquette d'objet n'intéresse que celui
  qui s'en approche, une enseigne de zone doit se voir de loin. Les enseignes
  sont posées **au-dessus de toute leur rangée** : celle des œufs était à la
  même hauteur que les étiquettes et le nom du monde se lisait comme un
  doublon du nom de l'œuf.
- **Le compteur de buts du vol ne calcule rien.** Il applique le
  `multiplicateurButs` que le serveur lui envoie dans le paquet `Synchro`,
  et se cale sur le total réel à l'arrivée (`Festival.conclure`). Il a déjà
  dérivé une fois, en recalculant avec l'ancien catalogue du stade.
- **Un seul format de nombres** : `Shared.Format.short` (680, 3.2K, 86.24B).
  `Arcade/Formatage.nombre` n'est plus qu'un renvoi vers lui.
- **Le profil du hub voyage dans l'enregistrement du stade.** Il part dans un
  champ `hub` de `Arcade/Donnees.Profil`, que `Donnees` transporte sans jamais
  le relire : c'est `Economy.serialize` / `Economy.deserialize` qui savent le
  lire et le vérifier contre les catalogues. Deux pièges ont déjà été évités
  là :
  - **`Economy` écoute `PlayerRemoving` avant la zone de tir**, donc il
    effaçait le profil avant qu'elle ne le sauvegarde. D'où `Store.flush`,
    appelé juste avant de libérer le profil.
  - **Le JSON du DataStore transforme les clés numériques en chaînes.** Les
    mondes partent donc en liste (`{1, 2}`) et non en table indexée par des
    nombres, sinon on relisait des mondes qu'on ne reconnaissait plus.
  Le profil n'est recopié qu'au moment d'écrire (`Donnees.brancherHub`) :
  la zone AFK marque le profil modifié plusieurs fois par seconde.

## Réglages fréquents

| Je veux… | Où |
|---|---|
| Changer prix ou puissance d'un ballon | `shared/Data/Balls.luau` |
| Changer prix ou multiplicateur d'un crampon | `shared/Data/Cleats.luau` |
| Changer une couleur, une police, une animation | `client/Hud/Theme.luau` |
| Basculer le bouton de renaissance en version feu | `Config.RenaissanceStyleFeu` |
| Régler la taille des étiquettes flottantes | `client/Signs.luau` (`TAILLE`) |
| Régler jusqu'où une étiquette s'affiche | `Build.PORTEE_ETIQUETTE` / `PORTEE_ENSEIGNE` |
| Changer le boost de Buts par renaissance | `Config.RenaissanceBoostParPalier` |
| Changer le boost de Puissance par renaissance | `shared/Progression.luau` |
| Changer la courbe de renaissance | `shared/Progression.luau` |
| Changer la courbe de frappe | `Config.FrappeAmortissement` |
| Changer la compression du tir | `Arcade/Config` (`VITESSE_RENDUE_MAX`) |
| Changer la zone de frappe parfaite | `Arcade/Config.SEUIL_PARFAIT` |
| Changer l'arrêt sur image du contact | `Arcade/Config.HITSTOP` |
| Changer les sons | `Arcade/Config.SONS` |
| Changer le cadrage de l'armement | `Arcade/Config.CAMERA` |
| Changer la vitesse du joueur | `Config.WalkSpeed` |
| Changer un effet de ballon | `shared/BallFx.luau` |
| Changer les gains AFK ou par tir | `shared/Config.luau` |
| Changer le prix ou le rendement d'un terrain AFK | `Config.AfkLanes` |
| Changer la taille des terrains AFK | `Layout.AFK_LANE_DEPTH` / `_LENGTH` |
| Changer le gain au clic | `Config.AfkPuissanceParClic` |
| Changer le coût ou le gain d'une fusion | `shared/Data/Fusion.luau` |
| Changer les temps de fabrication | `Fusion.ATTENTE` |
| Changer les paliers de temps de jeu | `shared/Data/Gifts.luau` |
| Déplacer la machine à fusion | `Layout.FUSION_POSITION` |
| Déplacer le kiosque de l'auto-clic | `Layout.AUTOCLIC_POSITION` |
| Déplacer le tableau des meilleurs | `Layout.CLASSEMENT_POSITION` |
| Changer la disposition de la boutique | `Map/BallShop.luau` (`PAR_RANGEE`, `ESTRADE`) |
| Régler quand le ballon s'arrête | `Arcade/Config.DELAI_APRES_COMPTEUR` |
| Mettre l'auto-clic en vente | `Config.AutoClicGamePassId` |
| Déplacer une zone du hub | `server/Map/Layout.luau` |
| Déplacer un monde | `Layout.CENTRES` |
| Régler la frappe, la caméra, le terrain | `shared/Arcade/Config.luau` |

## Ce qui reste à faire

- **L'équilibrage n'a jamais été joué en vrai**, seulement simulé avec
  `lune`. Les nombres sont à ajuster à la main. En particulier : les
  crampons légendaires tombent vers 55 min avec une jauge parfaite, mais
  vers 66 min avec une jauge moyenne — un peu au-delà de la fenêtre visée.
- **Le GamePass de l'auto-clic n'est pas créé.** Le service tourne et se teste
  avec F7, mais `Config.AutoClicGamePassId` vaut 0 : il faut créer le pass sur
  le site Roblox et coller son identifiant ici pour qu'il se vende.
- **Les mondes 2 et 3 ne se distinguent que par leurs œufs.** Ils sont
  construits et on y voyage, mais leurs terrains AFK ont le même rendement
  que ceux du monde 1 et leur pelouse la même couleur. C'est là qu'il faut
  travailler pour qu'ils vaillent leur prix.
- **La cinématique d'arrivée n'a pas encore été vue tourner.** Elle a échoué
  deux fois en silence (clonage du personnage, puis double non ancré qui
  tombait à travers le décor). Chaque échec se nomme désormais dans la
  Sortie, préfixé `Cinematique -` : c'est par là qu'il faut commencer. Les
  quatre messages possibles sont « pas de personnage », « avatar
  indisponible, on clone », « double impossible » et « animation refusée » —
  les trois premiers veulent dire qu'on ne voit rien, le dernier que la
  scène tourne mais que le double glisse sans bouger les jambes.
- **Le sourire du joueur dans la cinématique** n'est pas faisable : le
  visage d'un avatar est une texture, pas une expression qu'on pilote. Ce
  qui reste possible, c'est de lui faire jouer une émote pendant la course.
- **Les récompenses de temps de jeu n'ont jamais été réclamées en vrai.**
  Le panneau Cadeaux passe les vérifications, mais personne n'a encore
  attendu deux minutes pour voir un palier s'ouvrir.
- **Le bouton Inventaire** du menu latéral affiche « Bientôt disponible ».
